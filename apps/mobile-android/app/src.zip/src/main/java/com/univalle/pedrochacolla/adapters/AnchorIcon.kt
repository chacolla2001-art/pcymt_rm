package com.univalle.pedrochacolla.adapters

data class AnchorIcon(
    val anchorId: String,
    val iconUrl: String,
    val position: com.google.android.gms.maps.model.LatLng,
    val description: String
)