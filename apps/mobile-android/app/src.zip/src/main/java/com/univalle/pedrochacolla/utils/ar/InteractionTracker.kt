package com.univalle.pedrochacolla.utils.ar

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

object InteractionTracker {
    private const val PREF_NAME = "UserInteractionPrefs"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun hasInteractedToday(key: String): Boolean {
        val today = getToday()
        return prefs.getString(key, "") == today
    }

    fun setInteractionForToday(key: String) {
        prefs.edit().putString(key, getToday()).apply()
    }

    private fun getToday(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
}