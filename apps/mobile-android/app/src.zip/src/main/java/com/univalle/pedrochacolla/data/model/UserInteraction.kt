package com.univalle.pedrochacolla.data.model

import java.util.Date

data class UserInteraction(
    val id: String? = null,

    val interactionType: Int,        // Ej: 1=viewed, 2=liked

    val active: Boolean = true,

    val user_id: String,             // FK → UserData.userId

    val psa: String,                 // FK → AnchorPoint.id

    val cerm: String,                // FK → AnimalModel.id

    val created_at: Date? = null,
    val updated_at: Date? = null
)
