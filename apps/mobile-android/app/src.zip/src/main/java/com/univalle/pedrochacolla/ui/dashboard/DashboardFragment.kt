package com.univalle.pedrochacolla.ui.dashboard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.data.model.AnchorPoint
import com.univalle.pedrochacolla.data.remote.ApiService
import com.univalle.pedrochacolla.ui.dashboard.IconCarouselAdapter
import com.univalle.pedrochacolla.utils.constants.Constants
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import com.univalle.pedrochacolla.utils.session.UserSession
import kotlinx.coroutines.launch

class DashboardFragment : Fragment(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private val anchorMarkers = mutableListOf<Marker>()
    private val markerAnchorMap = mutableMapOf<Marker, AnchorPoint>()
    private var activeMarker: Marker? = null
    private var selectedAnchorPosition: LatLng? = null
    private var currentRoute: Polyline? = null

    // ** Nuevo campo para recibir el ID pasado desde MainFragment **
    private var selectedAnchorId: String? = null

    private lateinit var sensorManager: SensorManager
    private var rotationVectorSensor: Sensor? = null
    private var isNavigating = false

    private val orientationListener = object : SensorEventListener {
        private val rotationMatrix = FloatArray(9)
        private val orientationAngles = FloatArray(3)

        override fun onSensorChanged(event: SensorEvent?) {
            if (event?.sensor?.type == Sensor.TYPE_ROTATION_VECTOR
                && isNavigating
                && selectedAnchorPosition != null
            ) {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                val azimuthRadians = orientationAngles[0]
                val azimuthDegrees = Math.toDegrees(azimuthRadians.toDouble()).toFloat()
                val heading = (azimuthDegrees + 360) % 360

                map.animateCamera(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder()
                            .target(selectedAnchorPosition!!)
                            .zoom(map.cameraPosition.zoom)
                            .bearing(heading)
                            .tilt(45f)
                            .build()
                    )
                )
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ** Leer el argumento que viene de MainFragment **
        selectedAnchorId = arguments?.getString("selectedAnchorId")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)
        val mapFragment = SupportMapFragment.newInstance()
        childFragmentManager.beginTransaction()
            .replace(R.id.map_container, mapFragment)
            .commit()
        mapFragment.getMapAsync(this)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Configuración única del RecyclerView y SnapHelper
        val recyclerView = view.findViewById<RecyclerView>(R.id.icon_carousel)
        recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        LinearSnapHelper().attachToRecyclerView(recyclerView)

        // Sensor de orientación
        sensorManager = requireContext().getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        // Top card hide on click
        val topCard = view.findViewById<View>(R.id.top_card)
        topCard.setOnClickListener {
            topCard.animate()
                .translationY(-topCard.height.toFloat())
                .setDuration(300)
                .withEndAction { topCard.visibility = View.GONE }
                .start()
        }

        // Botón de navegación
        val navigateButton = view.findViewById<Button>(R.id.btn_navigate_to_anchor)
        navigateButton.setOnClickListener {
            handleNavigate(navigateButton)
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.registerListener(
            orientationListener,
            rotationVectorSensor,
            SensorManager.SENSOR_DELAY_UI
        )
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(orientationListener)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.apply {
            isCompassEnabled = true
            isMyLocationButtonEnabled = true
            isMapToolbarEnabled = false
        }
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            map.isMyLocationEnabled = true
        }
        val center = LatLng(-16.4882662, -68.1460941)
        map.moveCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(center)
                    .zoom(18f)
                    .bearing(252f)
                    .tilt(0f)
                    .build()
            )
        )
        // ** Llama a cargarAnchorPoints pasando el selectedAnchorId **
        cargarAnchorPoints(selectedAnchorId)

        map.setOnMarkerClickListener { clicked ->
            onMarkerSelected(clicked)
            true
        }
    }

    private fun handleNavigate(button: Button) {
        if (!isNavigating) {
            val loading = LoadingDialogFragment.newInstance().also {
                it.show(parentFragmentManager, "loading")
            }
            val fused = LocationServices.getFusedLocationProviderClient(requireActivity())
            if (ActivityCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(requireContext(), "Permiso de ubicación no concedido", Toast.LENGTH_SHORT)
                    .show()
                loading.dismiss()
                return
            }
            fused.lastLocation.addOnSuccessListener { loc ->
                loading.dismiss()
                if (loc != null && selectedAnchorPosition != null) {
                    drawRoute(loc.latitude, loc.longitude, selectedAnchorPosition!!, button)
                } else {
                    Toast.makeText(requireContext(), "Ubicación no disponible", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        } else {
            currentRoute?.remove()
            anchorMarkers.forEach { it.isVisible = true }
            activeMarker?.setIcon(
                BitmapDescriptorFactory.defaultMarker(
                    BitmapDescriptorFactory.HUE_RED
                )
            )
            activeMarker = null
            selectedAnchorPosition = null
            isNavigating = false
            button.text = "Cómo llegar"
        }
    }

    private fun drawRoute(
        lat: Double,
        lng: Double,
        dest: LatLng,
        button: Button
    ) {
        currentRoute?.remove()
        anchorMarkers.forEach {
            if (it != activeMarker) it.isVisible = false
        }
        val pattern = listOf(Dot(), Gap(20f))
        currentRoute = map.addPolyline(
            PolylineOptions()
                .add(LatLng(lat, lng), dest)
                .color(ContextCompat.getColor(requireContext(), R.color.purple_500))
                .width(8f)
                .geodesic(true)
                .pattern(pattern)
        )
        val bounds = LatLngBounds.builder()
            .include(LatLng(lat, lng))
            .include(dest)
            .build()
        map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
        isNavigating = true
        button.text = "Cancelar"
    }

    /**
     * Ahora acepta un parámetro opcional anchorToSelect: si no es null,
     * tras añadir los marcadores buscará y seleccionará ese ID.
     */
    private fun cargarAnchorPoints(anchorToSelect: String?) {
        val loading = LoadingDialogFragment.newInstance().also {
            it.show(parentFragmentManager, "loading")
        }
        lifecycleScope.launch {
            try {
                val token = UserSession.currentUser?.idToken
                if (token.isNullOrEmpty()) {
                    Toast.makeText(requireContext(), "Sesión inválida", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val api = ApiService()
                val all = api.getAllAnchorPoints(token) ?: emptyList()
                val visible = all.filter { it.showInMap == true }

                anchorMarkers.clear()
                markerAnchorMap.clear()

                visible.forEach { anchor ->
                    val pos = LatLng(anchor.latitude, anchor.longitude)
                    map.addMarker(
                        MarkerOptions()
                            .position(pos)
                            .title(anchor.name)
                            .snippet(anchor.description ?: "Sin descripción")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                    )?.also { m ->
                        anchorMarkers.add(m)
                        markerAnchorMap[m] = anchor
                    }
                }

                // ** Después de añadir todos, selecciona el que corresponda **
                anchorToSelect?.let { id ->
                    markerAnchorMap.entries
                        .firstOrNull { it.value.id == id }
                        ?.key
                        ?.let { marker ->
                            onMarkerSelected(marker)
                            map.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.position, 19f))
                        }
                }

                // Carrusel
                val recyclerView = requireView().findViewById<RecyclerView>(R.id.icon_carousel)
                val items = visible.mapNotNull { anchor ->
                    anchor.animalModelId?.let { id ->
                        api.getAnimalModelById(id, token)?.icon?.let { url ->
                            Triple(Constants.URL_BASE + url,
                                LatLng(anchor.latitude, anchor.longitude),
                                anchor.description ?: "Sin descripción")
                        }
                    }
                }
                recyclerView.adapter = IconCarouselAdapter(items) { (_, pos, desc) ->
                    // al clicar ítem del carrusel
                    activeMarker?.apply {
                        setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                        hideInfoWindow()
                    }
                    anchorMarkers.firstOrNull { it.position == pos }?.apply {
                        setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                        showInfoWindow()
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 19f))
                    }?.also {
                        activeMarker = it
                        selectedAnchorPosition = pos
                    }

                    val topCard = requireView().findViewById<View>(R.id.top_card)
                    val cardIcon = requireView().findViewById<ImageView>(R.id.card_icon)
                    val cardDesc = requireView().findViewById<TextView>(R.id.card_description)
                    topCard.visibility = View.VISIBLE
                    topCard.translationY = -topCard.height.toFloat()
                    topCard.animate().translationY(0f).duration = 300
                    Glide.with(requireContext()).load(Constants.URL_BASE + desc)
                        .into(cardIcon)
                    cardDesc.text = desc
                }

                map.setOnMapClickListener {
                    val topCard = requireView().findViewById<View>(R.id.top_card)
                    topCard.animate()
                        .translationY(-topCard.height.toFloat())
                        .setDuration(300)
                        .withEndAction { topCard.visibility = View.GONE }
                        .start()
                    activeMarker?.apply {
                        setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                        hideInfoWindow()
                    }
                    activeMarker = null
                }

            } finally {
                loading.dismiss()
            }
        }
    }

    private fun onMarkerSelected(marker: Marker) {
        activeMarker?.apply {
            setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
            hideInfoWindow()
        }
        marker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
        marker.showInfoWindow()
        activeMarker = marker
        selectedAnchorPosition = marker.position

        markerAnchorMap[marker]?.animalModelId?.let { modelId ->
            lifecycleScope.launch {
                val loading = LoadingDialogFragment.newInstance().also {
                    it.show(parentFragmentManager, "loading")
                }
                try {
                    val token = UserSession.currentUser?.idToken
                    if (token.isNullOrEmpty()) {
                        Toast.makeText(requireContext(), "Sesión inválida", Toast.LENGTH_SHORT).show()
                        return@launch
                    }
                    val model = ApiService().getAnimalModelById(modelId, token)
                    model?.icon?.let { iconUrl ->
                        val topCard = requireView().findViewById<View>(R.id.top_card)
                        val cardIcon = requireView().findViewById<ImageView>(R.id.card_icon)
                        val cardDesc = requireView().findViewById<TextView>(R.id.card_description)
                        topCard.visibility = View.VISIBLE
                        topCard.translationY = -topCard.height.toFloat()
                        topCard.animate().translationY(0f).duration = 300
                        Glide.with(requireContext()).load(Constants.URL_BASE + iconUrl)
                            .into(cardIcon)
                        cardDesc.text = model.description ?: "Sin descripción"
                    }
                } finally {
                    loading.dismiss()
                }
            }
        }
    }
}
