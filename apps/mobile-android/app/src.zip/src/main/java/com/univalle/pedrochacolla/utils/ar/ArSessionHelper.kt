package com.univalle.pedrochacolla.utils.ar

import android.annotation.SuppressLint
import android.view.MotionEvent
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Config
import io.github.sceneview.ar.ARSceneView

/**
 * Helper para configurar la sesión AR y manejar taps sobre planos.
 */
class ArSessionHelper(
    private val sceneView: ARSceneView
) {

    private var onPlaneTap: ((HitResult) -> Unit)? = null

    /**
     * Inicializa la sesión AR con cloud anchors y maneja taps.
     * @param onPlaneTap callback que recibe el HitResult cuando el usuario toca un plano.
     */
    @SuppressLint("ClickableViewAccessibility")
    fun setupSession(onPlaneTap: (HitResult) -> Unit) {
        this.onPlaneTap = onPlaneTap

        // Configurar la sesión AR
        sceneView.onSessionCreated = { session ->
            val config = session.config
            config.cloudAnchorMode = Config.CloudAnchorMode.ENABLED
            session.configure(config)
        }

        // Manejar taps en la pantalla, filtrando sólo planos detectados
        sceneView.setOnTouchListener { _, event: MotionEvent ->
            if (event.action == MotionEvent.ACTION_UP) {
                val frame = sceneView.frame ?: return@setOnTouchListener true
                val hitResult = frame.hitTest(event.x, event.y)
                    .firstOrNull { it.trackable is Plane }
                hitResult?.let(onPlaneTap)
            }
            true
        }
    }
}
