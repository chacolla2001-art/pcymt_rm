package com.univalle.pedrochacolla.utils.constants

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.data.remote.ApiService
import com.univalle.pedrochacolla.databinding.FragmentCollectionBinding
import com.univalle.pedrochacolla.utils.session.UserSession
import kotlinx.coroutines.launch

class CollectionFragment : Fragment() {

    private var _binding: FragmentCollectionBinding? = null
    private val binding get() = _binding!!

    // Simula cuántas figuras hay en total
    private val totalFigures = 10

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentCollectionBinding.inflate(inflater, container, false)
        .also { _binding = it }
        .root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val user = UserSession.currentUser
        val name = user?.fullName?.takeIf { it.isNotBlank() } ?: "invitado"
        binding.tvWelcome.text = "¡Bienvenido, $name!"

        val token = user?.idToken ?: return
        val userId = user.userId

        val api = ApiService()
        val tvStats = binding.tvStats
        val progressStats = binding.progressStats

        // Mostrar solo el loader al inicio
        tvStats.visibility = View.GONE
        progressStats.visibility = View.VISIBLE


        val overlay = binding.loadingOverlay

        overlay.visibility = View.VISIBLE // Muestra loader encima del texto

        lifecycleScope.launch {
            val allAnchors = api.getAllAnchorPoints(token) ?: emptyList()
            val visibleAnchors = allAnchors.filter { it.active == true && it.showInMap == true }

            val interactedAnchors = api.getInteractedAnchors(userId, token)
            val found = visibleAnchors.count { it.id in interactedAnchors }
            tvStats.text = "Has encontrado $found de ${visibleAnchors.size} figuras"

            overlay.visibility = View.GONE // Oculta loader
            tvStats.visibility = View.VISIBLE // Muestra el texto

        }


        binding.btnGoCollection.setOnClickListener {
            findNavController().navigate(R.id.navigation_main)
        }
        binding.btnGoMap.setOnClickListener {
            findNavController().navigate(R.id.navigation_dashboard)
        }
        binding.btnProfile.setOnClickListener {
            findNavController().navigate(R.id.navigation_notifications)
        }
        binding.btnAR.setOnClickListener {
            findNavController().navigate(R.id.navigation_home)
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
