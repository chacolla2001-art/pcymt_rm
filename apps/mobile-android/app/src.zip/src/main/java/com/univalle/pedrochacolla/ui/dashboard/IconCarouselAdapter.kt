package com.univalle.pedrochacolla.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.maps.model.LatLng
import com.univalle.pedrochacolla.R

class IconCarouselAdapter(
    private val icons: List<Triple<String, LatLng, String>>, // iconURL, anchor, desc
    private val onClick: (Triple<String, LatLng, String>) -> Unit
) : RecyclerView.Adapter<IconCarouselAdapter.IconViewHolder>() {

    class IconViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val iconImage: ImageView = view.findViewById(R.id.iconImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IconViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_icon_carousel, parent, false)
        return IconViewHolder(view)
    }

    override fun onBindViewHolder(holder: IconViewHolder, position: Int) {
        val (iconUrl, _, _) = icons[position]
        Glide.with(holder.iconImage.context)
            .load(iconUrl)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .into(holder.iconImage)

        holder.iconImage.setOnClickListener {
            onClick(icons[position])
        }
    }

    override fun getItemCount(): Int = icons.size
}


