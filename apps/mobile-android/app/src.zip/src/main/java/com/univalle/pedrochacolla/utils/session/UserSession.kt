package com.univalle.pedrochacolla.utils.session

import com.univalle.pedrochacolla.data.model.UserData

object UserSession {
    var currentUser: UserData? = null

    fun clear() {
        currentUser = null
    }
}
