package com.univalle.pedrochacolla.data.model

import org.json.JSONObject

data class UserData(
    val idToken: String? = null,              // el token JWT
    val userId: String = "",                  // user_id
    val username: String = "",                // username
    val email: String = "",                   // email
    val password: String? = null,             // contraseña para registrar/actualizar
    val userRole: String = "user",            // user_role
    val active: Boolean = true,               // active
    val fullName: String? = null,             // full_name
    val firstLastname: String? = null,        // first_lastname
    val secondLastname: String? = null,       // second_lastname
    val idCardNumber: String? = null,         // id_card_number
    val profilePictureUrl: String? = null,    // profile_picture_url
    val createdAt: String? = null,            // created_at
    val updatedAt: String? = null             // updated_at
) {
    /**
     * Para el registro o actualización en el back,
     * usa exactamente las mismas claves que espaera Sequelize.
     */
    fun toRegisterMap(): Map<String, Any> = mapOf(
        "username"             to username,
        "email"                to email,
        "password_hash"        to (password ?: ""),
        "user_role"            to userRole,
        "active"               to active,
        "full_name"            to (fullName ?: ""),
        "first_lastname"       to (firstLastname ?: ""),
        "second_lastname"      to (secondLastname ?: ""),
        "id_card_number"       to (idCardNumber ?: ""),
        "profile_picture_url"  to (profilePictureUrl ?: "")
    )

    companion object {
        /**
         * Construye UserData a partir del JSON recibido del back (subobjeto "user").
         */
        fun fromJson(token: String, json: JSONObject): UserData {
            return UserData(
                idToken           = token,
                userId            = json.optString("user_id", ""),
                username          = json.optString("username", ""),
                email             = json.optString("email", ""),
                password          = null,  // no viene en la respuesta
                userRole          = json.optString("user_role", "user"),
                active            = json.optBoolean("active", true),
                fullName          = json.optString("full_name", null),
                firstLastname     = json.optString("first_lastname", null),
                secondLastname    = json.optString("second_lastname", null),
                idCardNumber      = json.optString("id_card_number", null),
                profilePictureUrl = json.optString("profile_picture_url", null),
                createdAt         = json.optString("created_at", null),
                updatedAt         = json.optString("updated_at", null)
            )
        }
    }
}
