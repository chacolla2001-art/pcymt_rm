package com.univalle.pedrochacolla.data.repository

import android.content.Context
import android.util.Log
import com.univalle.pedrochacolla.data.remote.ApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Response
import org.json.JSONObject
import java.io.File

class AuthRepository(context: Context) {
    private val apiService = ApiService()

    suspend fun loginWithGoogleIdToken(idToken: String): Result<Pair<String, JSONObject>> {
        return apiService.loginWithGoogle(idToken)
    }

    suspend fun loginWithEmail(
        email: String,
        password: String
    ): Result<Pair<String, JSONObject>> = withContext(Dispatchers.IO) {
        try {
            // Llamada de red en IO
            val response = apiService.post(
                "/api/users/login",
                mapOf(
                    "email" to email,
                    "password" to password,
                    "platform" to "mobile"
                )
            )

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Error HTTP: ${response.code}"))
            }

            // Leer el body en IO
            val bodyStr = response.body?.string().orEmpty()
            val json = JSONObject(bodyStr)
            // Extraer token
            val token = json.optString("token").ifEmpty {
                return@withContext Result.failure(Exception("Token no encontrado"))
            }

            // Éxito
            Result.success(Pair(token, json))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerUser(data: Map<String, Any>): Response {
        return withContext(Dispatchers.IO) {
            apiService.post("/api/users/register", data)
        }
    }


    suspend fun updateUser(userId: String, updatedData: Map<String, Any>) =
        runCatching { apiService.put("/api/users/$userId", updatedData) }.mapCatching {
            if (it.isSuccessful) Unit else throw Exception("Error ${it.code}: ${it.message}")
        }

    fun isUserLoggedIn(authPrefs: android.content.SharedPreferences): Boolean {
        return authPrefs.getString("idToken", null) != null
    }
    private val api = ApiService()

    suspend fun uploadProfilePhoto(
        userId: String,
        file: File,
        token: String
    ): Result<String> = runCatching {
        val resp = api.updateProfilePhoto(userId, file, token)
        if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
        // El backend devuelve { profile_picture_url: "..."} en JSON
        val json = JSONObject(resp.body!!.string())
        json.getString("profile_picture_url")
    }
    suspend fun emailExists(email: String): Boolean {
        return apiService.checkEmailExistence(email)
    }

    suspend fun usernameExists(username: String): Boolean {
        return apiService.checkUsernameExistence(username)
    }

    suspend fun idCardExists(ci: String): Boolean {
        return apiService.checkIdCardExistence(ci)
    }


}
