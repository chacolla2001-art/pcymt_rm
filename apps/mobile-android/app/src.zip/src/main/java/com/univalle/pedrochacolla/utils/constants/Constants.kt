package com.univalle.pedrochacolla.utils.constants
object Constants {
    const val WEB_CLIENT_ID = "715749958092-5jeagq1aj7100t8frmg6pvson85j7842.apps.googleusercontent.com"
    const val URL_LOGGING_GOOGLE = "/api/google-login/logeo"
    const val URL_BASE="http://192.168.159.235:5000"
}