package com.univalle.pedrochacolla.ui.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.univalle.pedrochacolla.MainActivity
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.databinding.FragmentFirstBinding
import com.univalle.pedrochacolla.utils.auth.GoogleSignInHelper
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import com.univalle.pedrochacolla.utils.session.SessionManager
import com.univalle.pedrochacolla.utils.window.BannerUtil
import kotlinx.coroutines.launch

class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null
    private val binding get() = _binding!!

    private lateinit var sessionManager: SessionManager
    private var isRememberMeActive = false
    private var suppressSwitchListener = true
    private var loadingDialog: LoadingDialogFragment? = null

    private val viewModel by viewModels<LoginViewModel> {
        LoginViewModelFactory(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        // Inicializar switch "Recuérdame"
        isRememberMeActive = sessionManager.isRememberMeEnabled()
        suppressSwitchListener = true
        binding.switch1.isChecked = isRememberMeActive
        suppressSwitchListener = false

        binding.switch1.setOnCheckedChangeListener { _, isChecked ->
            if (!suppressSwitchListener) {
                isRememberMeActive = isChecked
                sessionManager.setRememberMe(isChecked)
            }
        }

        // Prellenar campos si se eligió "Recuérdame"
        when (sessionManager.getLoginMethod()) {
            "email" -> {
                val (email, password) = sessionManager.getSavedCredentials()
                binding.etEmailLoginInput.setText(email)
                binding.etPasswordLoginInput.setText(password)
            }
            "google" -> {
                //if (isRememberMeActive) launchGoogleSignIn()
            }
        }

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmailLoginInput.text.toString().trim()
            val password = binding.etPasswordLoginInput.text.toString().trim()

            var hasError = false

            // Validación de email
            if (email.isEmpty()) {
                binding.etEmailLogin.error = "El correo es obligatorio"
                binding.etEmailLoginInput.requestFocus()
                hasError = true
            } else {
                binding.etEmailLogin.error = null
            }

            // Validación de contraseña
            if (password.isEmpty()) {
                binding.etPasswordLogin.error = "La contraseña es obligatoria"
                if (!hasError) {
                    binding.etPasswordLoginInput.requestFocus()
                }
                hasError = true
            } else {
                binding.etPasswordLogin.error = null
            }

            if (hasError) return@setOnClickListener

            // Si no hay errores, continúa
            viewModel.loginWithEmailAndPassword(email, password, isRememberMeActive)
        }

        binding.etEmailLoginInput.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) binding.etEmailLogin.error = null
        }

        binding.etPasswordLoginInput.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) binding.etPasswordLogin.error = null
        }

        binding.btnContinueGoogle.setOnClickListener {
            launchGoogleSignIn()
        }

        binding.btnGoRegister.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }

        observeAuthState()
    }

    private fun launchGoogleSignIn() {
        val googleSignInHelper = GoogleSignInHelper(
            context = requireContext(),
            activity = requireActivity(),
            onTokenReceived = { idToken ->
                viewModel.loginWithGoogle(idToken, isRememberMeActive)
            },
            onError = { errorMessage ->

            }
        )
        googleSignInHelper.launch()
    }

    private fun observeAuthState() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                when (state) {
                    is AuthUiState.Loading -> {
                        if (loadingDialog == null) {
                            loadingDialog = LoadingDialogFragment.newInstance()
                            loadingDialog?.show(parentFragmentManager, "loading")
                        }
                    }
                    is AuthUiState.LoginSuccess -> {
                        loadingDialog?.dismiss()
                        startActivity(Intent(requireContext(), MainActivity::class.java))
                        requireActivity().finish()
                    }
                    is AuthUiState.Error -> {
                        loadingDialog?.dismiss()

                        // Limpiar campos
                        binding.etEmailLoginInput.setText("")
                        binding.etPasswordLoginInput.setText("")
                        binding.etEmailLoginInput.requestFocus()

                        // Mostrar errores en los campos
                        binding.etEmailLogin.error = "Correo incorrecto"
                        binding.etPasswordLogin.error = "Contraseña incorrecta"




                        BannerUtil.showBanner(requireActivity(), "Credenciales inválidas. Intenta de nuevo.")

                    }
                    else -> Unit
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
