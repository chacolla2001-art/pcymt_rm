package com.univalle.pedrochacolla.ui.home

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.ar.core.Config
import com.google.ar.core.Plane
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.univalle.pedrochacolla.MainActivity
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.data.model.AnchorPoint
import com.univalle.pedrochacolla.data.remote.ApiService
import com.univalle.pedrochacolla.databinding.FragmentHomeBinding
import com.univalle.pedrochacolla.utils.constants.Constants
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import io.github.sceneview.ar.ARSceneView
import io.github.sceneview.ar.node.AnchorNode
import io.github.sceneview.ar.node.CloudAnchorNode
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Transform
import io.github.sceneview.node.ModelNode
import kotlinx.coroutines.launch
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Handler
import android.os.HandlerThread
import com.univalle.pedrochacolla.utils.window.BannerUtil

import android.content.ContentValues
import android.graphics.Path
import android.os.Looper
import android.provider.MediaStore
import android.view.animation.LinearInterpolator
import com.univalle.pedrochacolla.data.model.AnimationClip
import com.univalle.pedrochacolla.data.model.UserInteraction
import com.univalle.pedrochacolla.utils.ar.InteractionTracker
import com.univalle.pedrochacolla.utils.session.UserSession
import org.json.JSONArray
import android.view.MotionEvent

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var sceneView: ARSceneView
    private var anchorNode: AnchorNode? = null
    private var cloudAnchorNode: CloudAnchorNode? = null
    private var modelNode: ModelNode? = null

    private var isFabMenuOpen = false
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var qualityUpdateHandler: Handler? = null
    private var qualityUpdateRunnable: Runnable? = null
    private var currentState: Estado = Estado.INICIO

    private enum class Estado {
        INICIO,
        ESPERANDO_TOQUE_PARA_ANCLA,
        ANCLA_COLOCADA,
        CAPTURANDO_CALIDAD,
        BUSCANDO_ANCLA
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)



        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val userRole = UserSession.currentUser?.userRole ?: "user"

        // Mostrar u ocultar botón de host según el rol
        if (userRole != "admin") {
            binding.btnHostAnchor.visibility = View.GONE
        }

        sceneView = binding.sceneView.apply {
            lifecycle = viewLifecycleOwner.lifecycle
            configureSession { session, config ->
                config.cloudAnchorMode = Config.CloudAnchorMode.ENABLED
                config.instantPlacementMode = Config.InstantPlacementMode.DISABLED
                config.depthMode = Config.DepthMode.AUTOMATIC
                config.lightEstimationMode = Config.LightEstimationMode.ENVIRONMENTAL_HDR
            }
            if (userRole != "admin") {
                planeRenderer.isVisible = false
            }
        }
        ////dsadsadsadasd
        sceneView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                ocultarPanelDescripcion()
            }
            false // IMPORTANTE: devolver false para no interferir con otros eventos
        }
        ////dsadsadsadasd
        binding.btnReturnNav.setOnClickListener {
            (requireActivity() as? MainActivity)?.mostrarBottomNavBar()
            findNavController().navigate(R.id.navigation_notifications)
        }

        hideFabMenu()
        binding.etInstructionsAnchor.visibility = View.GONE
        binding.fabMenu.visibility = View.GONE
        binding.btnUploadAnchor.visibility = View.GONE
        binding.btnCancelSearch.visibility = View.GONE

        // Texto en blanco
        binding.etAnchorDescription.text=""
        binding.btnTakePhoto.setOnClickListener {
            capturarFotoSceneView()
        }
        binding.etAnchorDescription.visibility = View.GONE
        binding.btnHostAnchor.setOnClickListener {
            when (currentState) {
                Estado.INICIO -> {
                    currentState = Estado.ESPERANDO_TOQUE_PARA_ANCLA
                    binding.etInstructionsAnchor.text = "Pulsa sobre una parte de la superficie para colocar un ancla"
                    binding.etInstructionsAnchor.visibility = View.VISIBLE
                    binding.btnResolveAnchors.visibility = View.GONE

                    binding.btnHostAnchor.text = "Atrás"
                    activarModoColocarAncla()
                }
                Estado.ESPERANDO_TOQUE_PARA_ANCLA,
                Estado.ANCLA_COLOCADA -> volverAlInicio()

                Estado.CAPTURANDO_CALIDAD -> {

                    binding.fabMenu.visibility = View.VISIBLE
                    binding.fabScaleUp.visibility = View.VISIBLE
                    binding.fabScaleDown.visibility = View.VISIBLE
                    binding.fabRotateLeft.visibility = View.VISIBLE
                    binding.fabRotateRight.visibility = View.VISIBLE
                    binding.qualityIndicatorContainer.visibility = View.GONE
                    modelNode?.apply {
                        isEditable = true
                        isPositionEditable = true
                        isRotationEditable = true
                        isScaleEditable = true
                    }
                    cloudAnchorNode?.isEditable = true
                    binding.btnUploadAnchor.text = "Subir"
                    currentState = Estado.ANCLA_COLOCADA
                }

                else -> {}
            }
        }


        binding.btnResolveAnchors.setOnClickListener {
            currentState = Estado.BUSCANDO_ANCLA
            binding.btnHostAnchor.visibility = View.GONE
            binding.btnCancelSearch.visibility = View.VISIBLE
            binding.etAnchorDescription.visibility = View.VISIBLE
            binding.etInstructionsAnchor.text = "Buscando anclas disponibles..."
            binding.etInstructionsAnchor.visibility = View.VISIBLE
            buscarAnclasRemotas()
        }

        binding.btnCancelSearch.setOnClickListener {
            volverAlInicio()
        }

        binding.fabMenu.setOnClickListener {
            if (isFabMenuOpen) hideFabMenu() else showFabMenu()
        }

        binding.fabScaleUp.setOnClickListener {
            modelNode?.scale = modelNode?.scale?.times(1.1f)!!
        }

        binding.fabScaleDown.setOnClickListener {
            modelNode?.scale = modelNode?.scale?.times(0.9f)!!
        }

        binding.fabRotateLeft.setOnClickListener {
            modelNode?.rotation = modelNode?.rotation?.let {
                Rotation(it.x, it.y - 15f, it.z)
            }!!
        }

        binding.fabRotateRight.setOnClickListener {
            modelNode?.rotation = modelNode?.rotation?.let {
                Rotation(it.x, it.y + 15f, it.z)
            }!!
        }

        binding.btnUploadAnchor.setOnClickListener {
            when (currentState) {
                Estado.ANCLA_COLOCADA -> {
                    // Cambia a modo de evaluación de calidad
                    binding.qualityIndicatorContainer.visibility = View.VISIBLE


                    //  Ocultar todos los FABs
                    binding.fabMenu.visibility = View.GONE
                    binding.fabScaleUp.visibility = View.GONE
                    binding.fabScaleDown.visibility = View.GONE
                    binding.fabRotateLeft.visibility = View.GONE
                    binding.fabRotateRight.visibility = View.GONE

                    // Desactivar edición del modelo y ancla
                    modelNode?.apply {
                        isEditable = false
                        isPositionEditable = false
                        isRotationEditable = false
                        isScaleEditable = false
                    }
                    cloudAnchorNode?.isEditable = false

                    // Cambiar texto del botón
                    binding.btnUploadAnchor.text = "Subir ancla"

                    currentState = Estado.CAPTURANDO_CALIDAD
                    iniciarActualizacionCalidad()
                }
                Estado.CAPTURANDO_CALIDAD -> {
                    detenerActualizacionCalidad()
                    subirAncla()
                }

                Estado.INICIO -> TODO()
                Estado.ESPERANDO_TOQUE_PARA_ANCLA -> TODO()
                Estado.BUSCANDO_ANCLA -> TODO()
            }
        }


        requireActivity().window.setDecorFitsSystemWindows(true)
        requireActivity().window.insetsController?.apply {
            show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_DEFAULT
        }


        requireActivity().window.decorView.setOnTouchListener(null)
    }
    private fun detenerActualizacionCalidad() {
        qualityUpdateHandler?.removeCallbacks(qualityUpdateRunnable!!)
        qualityUpdateHandler = null
        qualityUpdateRunnable = null
    }

    private fun iniciarActualizacionCalidad() {
        val session = sceneView.session ?: return
        val indicator = binding.qualityIndicator
        val indicatorText = binding.qualityText
        val container = binding.qualityIndicatorContainer

        container.visibility = View.VISIBLE

        qualityUpdateHandler = Handler()
        qualityUpdateRunnable = object : Runnable {
            override fun run() {
                val frame = sceneView.frame ?: return
                val cameraPose = frame.camera.pose
                val quality = session.estimateFeatureMapQualityForHosting(cameraPose)

                val scaleX = ObjectAnimator.ofFloat(indicator, View.SCALE_X, 1f, 1.2f, 1f)
                val scaleY = ObjectAnimator.ofFloat(indicator, View.SCALE_Y, 1f, 1.2f, 1f)
                AnimatorSet().apply {
                    playTogether(scaleX, scaleY)
                    duration = 600
                    interpolator = DecelerateInterpolator()
                    start()
                }

                when (quality) {
                    Session.FeatureMapQuality.INSUFFICIENT -> {
                        indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.red))
                        indicatorText.text = "Escanee más alrededor"
                    }
                    Session.FeatureMapQuality.SUFFICIENT -> {
                        indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.orange))
                        indicatorText.text = "Aceptable, pero puede mejorar"
                    }
                    Session.FeatureMapQuality.GOOD -> {
                        indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.green))
                        indicatorText.text = "Calidad adecuada"
                    }
                }

                // Repetir cada segundo
                qualityUpdateHandler?.postDelayed(this, 1000)
            }
        }

        qualityUpdateHandler?.post(qualityUpdateRunnable!!)
    }

    private fun volverAlInicio() {




        cloudAnchorNode?.let {
            sceneView.removeChildNode(it)
            it.destroy()
        }
        cloudAnchorNode = null
        anchorNode = null
        modelNode = null

        sceneView.setOnTouchListener(null)
        hideFabMenu()
        binding.iconScanHand.visibility = View.GONE
        binding.etInstructionsAnchor.visibility = View.GONE
        binding.fabMenu.visibility = View.GONE
        binding.btnUploadAnchor.visibility = View.GONE
        binding.etAnchorDescription.visibility = View.GONE

        binding.btnResolveAnchors.visibility = View.VISIBLE
        //ABBA
        if (UserSession.currentUser?.userRole == "admin")
        {
            binding.btnHostAnchor.visibility = View.VISIBLE
        }
        binding.btnCancelSearch.visibility = View.GONE
        binding.btnHostAnchor.text = "Colocar ancla"

        currentState = Estado.INICIO
    }

    private fun activarModoColocarAncla() {
        if (UserSession.currentUser?.userRole != "admin") return






        sceneView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP && currentState == Estado.ESPERANDO_TOQUE_PARA_ANCLA) {
                val frame = sceneView.frame ?: return@setOnTouchListener true
                val hit = frame.hitTest(event.x, event.y)
                    .firstOrNull {
                        it.trackable is Plane && (it.trackable as Plane).isPoseInPolygon(it.hitPose)
                    }
                if (hit != null) {
                    addAnchorNode(hit.createAnchor())
                    binding.etInstructionsAnchor.visibility = View.GONE
                    binding.fabMenu.visibility = View.VISIBLE
                    binding.btnUploadAnchor.visibility = View.VISIBLE
                    binding.etAnchorDescription.visibility = View.VISIBLE

                    // Ocultar indicador de calidad
                    binding.qualityIndicatorContainer.visibility = View.GONE

                    binding.btnUploadAnchor.text = "Subir"

                    currentState = Estado.ANCLA_COLOCADA
                    sceneView.setOnTouchListener(null)
                } else {
                    Toast.makeText(context, "Toca una superficie válida", Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
    }

    private fun addAnchorNode(anchor: com.google.ar.core.Anchor) {
        cloudAnchorNode = CloudAnchorNode(sceneView.engine, anchor).apply {
            isEditable = true
            lifecycleScope.launch {
                modelNode = buildLocalModelNode()
                modelNode?.let {
                    addChildNode(it)
                }
            }
        }
        cloudAnchorNode?.let { sceneView.addChildNode(it) }
    }

    private suspend fun buildModelNode(): ModelNode? {
        val modelInstance = sceneView.modelLoader.loadModelInstance(
            "https://sceneview.github.io/assets/models/Hair.glb"
        ) ?: return null

        return ModelNode(
            modelInstance = modelInstance,
            scaleToUnits = 0.5f,
            centerOrigin = Position(y = -0.5f)
        ).apply {
            isEditable = true
        }
    }

    private fun subirAncla() {
        val session = sceneView.session ?: return
        val cloudNode = cloudAnchorNode ?: return

        // Obtener la pose actual de la cámara
        val frame = sceneView.frame ?: return
        val cameraPose = frame.camera.pose

        // Estimar la calidad del mapa de características
        val quality = session.estimateFeatureMapQualityForHosting(cameraPose)

        val indicator = binding.qualityIndicator
        val indicatorText = binding.qualityText
        val container = binding.qualityIndicatorContainer

        container.visibility = View.VISIBLE

// Animación de pulso
        val scaleX = ObjectAnimator.ofFloat(indicator, View.SCALE_X, 1f, 1.2f, 1f)
        val scaleY = ObjectAnimator.ofFloat(indicator, View.SCALE_Y, 1f, 1.2f, 1f)
        AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            duration = 600
            interpolator = DecelerateInterpolator()
            start()
        }

        when (quality) {
            Session.FeatureMapQuality.INSUFFICIENT -> {
                indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.red))
                indicatorText.text = "Escanee más alrededor"
                return
            }
            Session.FeatureMapQuality.SUFFICIENT -> {
                indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.orange))
                indicatorText.text = "Aceptable, pero puede mejorar"
                return
            }
            Session.FeatureMapQuality.GOOD -> {
                indicator.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.green))
                indicatorText.text = "Calidad adecuada"
            }
        }


        val anchor = session.createAnchor(cloudNode.transform.toPose())
        cloudNode.anchor = anchor

        val loadingDialog = LoadingDialogFragment.newInstance()
        loadingDialog.show(parentFragmentManager, "loading")

        cloudNode.host(session) { cloudAnchorId, state ->
            if (state.isError || cloudAnchorId == null) {
                loadingDialog.dismiss()
                Toast.makeText(requireContext(), "Error al subir ancla: ${state.name}", Toast.LENGTH_LONG).show()
                return@host
            }

            if (ContextCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    if (location == null) {
                        Toast.makeText(requireContext(), "No se pudo obtener la ubicación", Toast.LENGTH_LONG).show()
                        loadingDialog.dismiss()
                        volverAlInicio()
                        return@addOnSuccessListener
                    }


                    val scale = modelNode?.scale?.x ?: 1.0f
                    val rotationY = modelNode?.rotation?.y ?: 0.0f

                    val anchorPoint = AnchorPoint(
                        name = "Anchor-${cloudAnchorId.take(8)}",
                        anchorCode = "CloudAnchorId: $cloudAnchorId",
                        latitude = location.latitude,
                        longitude = location.longitude,
                        scale = scale,
                        rotationY = rotationY
                    )


                    lifecycleScope.launch {
                        try {
                            val token = UserSession.currentUser?.idToken ?: run {
                                Toast.makeText(context, "Usuario no autenticado", Toast.LENGTH_LONG).show()
                            }
                            val success = ApiService().createAnchorPoint(token.toString(), anchorPoint)

                            if (success) {
                                BannerUtil.showBanner(requireActivity(), "AnchorPoint subido con éxito ")
                                binding.qualityIndicatorContainer.visibility = View.GONE
                                volverAlInicio()
                            } else {
                                Toast.makeText(context, "Error al registrar el AnchorPoint en el servidor", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error inesperado: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            loadingDialog.dismiss()
                        }
                    }

                }
            } else {
                loadingDialog.dismiss()
                Toast.makeText(requireContext(), "Permiso de ubicación no concedido", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun buscarAnclasRemotas() {
        binding.iconScanHand.visibility = View.VISIBLE

        binding.iconScanHand.post {
            val view = binding.iconScanHand
            val originalX = view.x
            val originalY = view.y
            val radius = 35f

            val animator = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 2000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                startDelay = 1000

                addUpdateListener { animation ->
                    val angleDeg = animation.animatedValue as Float
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val offsetX = (radius * Math.cos(angleRad)).toFloat()
                    val offsetY = (radius * Math.sin(angleRad)).toFloat()
                    view.x = originalX + offsetX
                    view.y = originalY + offsetY
                }
            }

            animator.start()
            view.tag = animator
        }

        val session = sceneView.session ?: return

        lifecycleScope.launch {
            val token = UserSession.currentUser?.idToken ?: run {
                Toast.makeText(context, "Usuario no autenticado", Toast.LENGTH_LONG).show()
            }
            val userId = UserSession.currentUser?.userId ?: return@launch
            val anchors = ApiService().getAllAnchorPoints(token.toString())
            anchors?.forEach { anchor ->

                val interactedAnchors: MutableSet<String> = ApiService()
                    .getInteractedAnchors(userId, token.toString())
                    .toMutableSet()

                val cloudAnchorId = anchor.anchorCode?.substringAfter("CloudAnchorId: ")?.trim()

                if (!cloudAnchorId.isNullOrEmpty()) {
                    CloudAnchorNode.resolve(sceneView.engine, session, cloudAnchorId) { state, node ->
                        if (!state.isError && node != null) {
                            lifecycleScope.launch {
                                val animalModelId = anchor.animalModelId
                                val animalModel = if (!animalModelId.isNullOrBlank()) {
                                    ApiService().getAnimalModelById(animalModelId, token.toString())
                                } else null

                                val modelNode = if (animalModel != null) {
                                    buildRemoteModelNode(sceneView, Constants.URL_BASE + animalModel.modelURL)
                                } else {
                                    buildLocalModelNode()
                                }

                                modelNode?.let { model ->
                                    model.scale = Position(anchor.scale, anchor.scale, anchor.scale)
                                    model.rotation = Rotation(y = anchor.rotationY)

                                    model.isEditable = false
                                    model.isPositionEditable = false
                                    model.isRotationEditable = false
                                    model.isScaleEditable = false

                                    node.isEditable = false
                                    node.addChildNode(model)
                                    sceneView.addChildNode(node)

                                    (binding.iconScanHand.tag as? ValueAnimator)?.cancel()
                                    binding.iconScanHand.clearAnimation()
                                    binding.iconScanHand.visibility = View.GONE
                                    binding.etInstructionsAnchor.visibility = View.GONE
                                    // --- Registrar interacción tipo 0 (visto) al cargar por primera vez ---
                                    ////////////////////////////////////////////////////
                                    model.onTouch = { hitResult, event ->
                                        // Solo queremos reaccionar al “soltar” (una única vez)
                                        if (hitResult.action == MotionEvent.ACTION_UP) {
                                            // Mostrar/ocultar descripción
                                            if (!anchor.description.isNullOrBlank()) {
                                                binding.tvAnchorDescription.text = anchor.description
                                                mostrarPanelDescripcion()
                                            } else {
                                                ocultarPanelDescripcion()
                                            }

                                            // Registrar interacción SOLO si no la tenemos hoy
                                            val anchorId = anchor.id.orEmpty()
                                            if (!interactedAnchors.contains(anchorId)) {
                                                val interaction = UserInteraction(
                                                    user_id         = userId,
                                                    cerm            = animalModel?.id.orEmpty(),
                                                    psa             = anchorId,
                                                    interactionType = 1
                                                )
                                                lifecycleScope.launch {
                                                    val success = ApiService()
                                                        .createUserInteraction(requireContext(), interaction)
                                                    if (success) {
                                                        interactedAnchors.add(anchorId)
                                                        BannerUtil.showBanner(requireActivity(), "Interacción registrada")
                                                    }
                                                }
                                            }
                                        }
                                        true
                                    }

                                    // Reproducir animación si hay secuencia
                                    if (!animalModel?.animation_sequence.isNullOrEmpty()) {
                                        animalModel?.animation_sequence?.let { sequence ->
                                            reproducirSecuenciaAnimaciones(model, sequence)
                                        }
                                    }

                                } ?: run {
                                    Toast.makeText(context, "No se pudo cargar ningún modelo para el ancla", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }
        }
    }




    private suspend fun buildRemoteModelNode(sceneView: ARSceneView, url: String): ModelNode? {
        val modelInstance = sceneView.modelLoader.loadModelInstance(url)
        return modelInstance?.let {
            ModelNode(
                modelInstance = it,

            ).apply {
                isEditable = true

            }
        }
    }

    private suspend fun buildLocalModelNode(): ModelNode? {
        val modelInstance = sceneView.modelLoader.loadModelInstance("models/cube.glb")
            ?: return null

        return ModelNode(
            modelInstance = modelInstance,
            scaleToUnits = 0.5f,
            centerOrigin = Position(y = -0.5f)
        ).apply {
            isEditable = true
        }
    }


    private fun showFabMenu() {
        listOf(binding.fabScaleUp, binding.fabScaleDown, binding.fabRotateLeft, binding.fabRotateRight).forEach {
            animateFab(it, -1f)
        }
        isFabMenuOpen = true
    }

    private fun hideFabMenu() {
        listOf(binding.fabScaleUp, binding.fabScaleDown, binding.fabRotateLeft, binding.fabRotateRight).forEach {
            hideFab(it)
        }
        isFabMenuOpen = false
    }

    private fun animateFab(fab: View, translationY: Float) {
        fab.visibility = View.VISIBLE
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(fab, View.TRANSLATION_Y, 0f, translationY),
                ObjectAnimator.ofFloat(fab, View.ALPHA, 0f, 1f)
            )
            duration = 300
            interpolator = DecelerateInterpolator()
            start()
        }
    }

    private fun hideFab(fab: View) {
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(fab, View.TRANSLATION_Y, fab.translationY, 0f),
                ObjectAnimator.ofFloat(fab, View.ALPHA, 1f, 0f)
            )
            duration = 200
            interpolator = DecelerateInterpolator()
            start()
        }.doOnEnd { fab.visibility = View.GONE }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    private fun capturarFotoSceneView() {
        // Crear un bitmap con las dimensiones de sceneView
        val bitmap = Bitmap.createBitmap(sceneView.width, sceneView.height, Bitmap.Config.ARGB_8888)

        // Crear un hilo de manejo para PixelCopy
        val handlerThread = HandlerThread("PixelCopyHelper")
        handlerThread.start()
        val handler = Handler(handlerThread.looper)

        // Solicitar la copia de píxeles
        PixelCopy.request(sceneView, bitmap, { copyResult ->
            requireActivity().runOnUiThread {
                if (copyResult == PixelCopy.SUCCESS) {
                    val filename = "AR_Capture_${System.currentTimeMillis()}.png"
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ARCaptures")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }

                    val resolver = requireContext().contentResolver
                    val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                    if (imageUri != null) {
                        try {
                            resolver.openOutputStream(imageUri).use { outStream ->
                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream!!)
                            }

                            contentValues.clear()
                            contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                            resolver.update(imageUri, contentValues, null, null)

                            BannerUtil.showBanner(
                                requireActivity(),
                                "Foto guardada en la galería 📸"
                            )
                        } catch (e: Exception) {
                            Toast.makeText(requireContext(), "Error al guardar imagen: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(requireContext(), "No se pudo acceder a la galería", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Error al capturar imagen: $copyResult", Toast.LENGTH_LONG).show()
                }
            }

        }, handler)

    }


    private fun mostrarPanelDescripcion() {
        val card = binding.anchorDescriptionCard
        card.visibility = View.VISIBLE
        card.translationY = -card.height.toFloat() - 200f
        card.alpha = 0f
        card.animate()
            .translationY(150f)  // posición final desde el top
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun ocultarPanelDescripcion() {
        val card = binding.anchorDescriptionCard
        card.animate()
            .translationY(-card.height.toFloat() - 200f)
            .alpha(0f)
            .setDuration(200)
            .withEndAction {
                card.visibility = View.GONE
            }
            .start()
    }
    private fun reproducirSecuenciaAnimaciones(modelNode: ModelNode, sequence: List<AnimationClip>) {
        currentAnimationHandler?.removeCallbacksAndMessages(null)
        isPlayingSequence = true
        currentAnimationHandler = Handler(Looper.getMainLooper())

        fun reproducirClip(index: Int) {
            if (sequence.isEmpty()) return

            val actualIndex = index % sequence.size
            val item = sequence[actualIndex]
            val clipIndex = item.clip
            val durationMs = (item.duration * 1000).toLong()

            try {
                // Detener cualquier animación activa
                modelNode.playingAnimations.keys.toList().forEach {
                    modelNode.stopAnimation(it)
                }

                modelNode.playAnimation(clipIndex, speed = 1.0f, loop = false)

                // Programar la siguiente animación tras duración exacta
                currentAnimationHandler?.postDelayed({
                    reproducirClip(actualIndex + 1)
                }, durationMs)

            } catch (e: Exception) {
                Log.w("Animación", "Error con el clip $clipIndex: ${e.message}")
                reproducirClip(actualIndex + 1)
            }
        }

        reproducirClip(0)
    }






    private var currentAnimationHandler: Handler? = null
    private var isPlayingSequence = false














}

// Extensión para convertir Transform a Pose
fun Transform.toPose(): Pose {
    val translation = floatArrayOf(position.x, position.y, position.z)
    val rotation = floatArrayOf(0f, 0f, 0f, 1f) // Sin rotación
    return Pose(translation, rotation)
}
