package com.univalle.pedrochacolla.data.model

// Define las zonas permitidas
enum class Section(val code: String) {
    ALTIPLANO("1"),
    VALLES("2"),
    LLANOS("3")
}

data class AnchorPoint(
    val id: String? = null,
    val name: String,
    val description: String? = null,
    val anchorCode: String? = null,
    val latitude: Double,
    val longitude: Double,
    /** Zona: ALTIPLANO="1", VALLES="2", LLANOS="3" */
    val section: Int = 1,
    /** Indica si debe mostrarse en el mapa */
    val showInMap: Boolean? = null,
    val scale: Float = 1.0f,
    val rotationY: Float = 0.0f,
    val animalModelId: String? = null,
    val active: Boolean = true,
    val createdAt: String? = null,
    val updatedAt: String? = null
)
