package com.univalle.pedrochacolla.ui.login

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.univalle.pedrochacolla.MainActivity
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.data.model.UserData
import com.univalle.pedrochacolla.databinding.FragmentSecondBinding
import com.univalle.pedrochacolla.utils.auth.GoogleSignInHelper
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import kotlinx.coroutines.launch

class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null
    private val binding get() = _binding!!
    private val viewModel by viewModels<LoginViewModel> {
        LoginViewModelFactory(requireContext())
    }

    private var loadingDialog: LoadingDialogFragment? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnGoLogin.setOnClickListener {
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }

        binding.btnRegister.setOnClickListener {
            registerUser()
        }

        binding.btnLoginGoogle.setOnClickListener {
            launchGoogleSignIn()
        }

        observeRegistrationState()
    }

    private fun registerUser() {
        val email = binding.etRegisterEmail.text.toString().trim()
        val password = binding.etRegisterPassword.text.toString().trim()
        val confirmPassword = binding.etRegisterPassword2.text.toString().trim()
        val idCard = binding.etRegisterIdcard.text.toString().trim()
        val fullName = binding.etRegisterFullname.text.toString().trim()
        val firstLastname = binding.etRegisterFirstlastname.text.toString().trim()
        val secondLastname = binding.etRegisterSecondlastname.text.toString().trim()
        val username = binding.etRegisterUsername.text.toString().trim()

        var hasError = false

        fun setError(layoutId: com.google.android.material.textfield.TextInputLayout, condition: Boolean, message: String) {
            if (condition) {
                layoutId.error = message
                if (!hasError) layoutId.requestFocus()
                hasError = true
            } else {
                layoutId.error = null
            }
        }

        setError(binding.tilRegisterEmail, email.isEmpty(), "Correo obligatorio")
        setError(binding.tilRegisterPassword, password.isEmpty(), "Contraseña obligatoria")
        setError(binding.tilRegisterPassword2, confirmPassword.isEmpty(), "Repita la contraseña")
        setError(binding.tilRegisterIdcard, idCard.isEmpty(), "CI obligatorio")
        setError(binding.tilRegisterFullname, fullName.isEmpty(), "Nombre completo obligatorio")
        setError(binding.tilRegisterFirstlastname, firstLastname.isEmpty(), "Primer apellido obligatorio")
        setError(binding.tilRegisterUsername, username.isEmpty(), "Username obligatorio")

        if (password != confirmPassword) {
            binding.tilRegisterPassword2.error = "Las contraseñas no coinciden"
            hasError = true
        }

        if (!esPasswordSegura(password)) {
            binding.tilRegisterPassword.error =
                "Debe tener al menos 12 caracteres, mayúsculas, minúsculas, números y símbolos"
            hasError = true
        }

        if (hasError) return

        val user = UserData(
            email = email,
            password = password,
            idCardNumber = idCard,
            fullName = fullName,
            firstLastname = firstLastname,
            secondLastname = secondLastname,
            username = username
        )

        lifecycleScope.launch {
            loadingDialog = LoadingDialogFragment.newInstance()
            loadingDialog?.show(parentFragmentManager, "loading")

            val emailExists = viewModel.checkEmailExists(email)
            val usernameExists = viewModel.checkUsernameExists(username)
            val idCardExists = viewModel.checkIdCardExists(idCard)

            loadingDialog?.dismiss()

            when {
                emailExists -> showBanner("El correo ya está registrado.")
                usernameExists -> showBanner("El nombre de usuario ya existe.")
                idCardExists -> showBanner("El número de CI ya fue usado.")
                else -> viewModel.registerUser(user)
            }
        }
    }

    private fun esPasswordSegura(password: String): Boolean {
        val longitudValida = password.length >= 12
        val contieneMayuscula = password.any { it.isUpperCase() }
        val contieneMinuscula = password.any { it.isLowerCase() }
        val contieneNumero = password.any { it.isDigit() }
        val contieneSimbolo = password.any { !it.isLetterOrDigit() }

        return longitudValida && contieneMayuscula && contieneMinuscula && contieneNumero && contieneSimbolo
    }

    private fun showBanner(message: String) {
        val activity = requireActivity()
        val banner = activity.findViewById<LinearLayout>(R.id.banner_overlay)
        val bannerMessage = banner.findViewById<TextView>(R.id.banner_message)
        val bannerClose = banner.findViewById<ImageButton>(R.id.banner_close)

        bannerMessage.text = message
        val slideIn = AnimationUtils.loadAnimation(requireContext(), R.anim.slide_in_top)
        banner.startAnimation(slideIn)
        banner.visibility = View.VISIBLE

        bannerClose.setOnClickListener {
            val slideOut = AnimationUtils.loadAnimation(requireContext(), R.anim.slide_out_top)
            banner.startAnimation(slideOut)
            banner.postDelayed({ banner.visibility = View.GONE }, 300)
        }

        banner.postDelayed({
            val slideOut = AnimationUtils.loadAnimation(requireContext(), R.anim.slide_out_top)
            banner.startAnimation(slideOut)
            banner.postDelayed({ banner.visibility = View.GONE }, 300)
        }, 3000)
    }

    private fun launchGoogleSignIn() {
        val googleSignInHelper = GoogleSignInHelper(
            context = requireContext(),
            activity = requireActivity(),
            onTokenReceived = { idToken ->
                viewModel.loginWithGoogle(idToken, false)
            },
            onError = { errorMessage ->
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
            }
        )
        googleSignInHelper.launch()
    }

    private fun observeRegistrationState() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                when (state) {
                    is AuthUiState.Loading -> {
                        if (loadingDialog == null) {
                            loadingDialog = LoadingDialogFragment.newInstance()
                            loadingDialog?.show(parentFragmentManager, "loading")
                        }
                    }
                    is AuthUiState.LoginSuccess -> {
                        loadingDialog?.dismiss()
                        Toast.makeText(requireContext(), "Registro exitoso", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(requireContext(), MainActivity::class.java))
                        requireActivity().finish()
                    }
                    is AuthUiState.Error -> {
                        loadingDialog?.dismiss()
                        showBanner("Error: ${state.message}")
                    }
                    else -> Unit
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
