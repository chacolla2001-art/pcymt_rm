package com.univalle.pedrochacolla.ui.login

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    object LoginSuccess : AuthUiState()
    object RegisterSuccess : AuthUiState()
    object UpdateSuccess : AuthUiState()
    data class Error(val message: String) : AuthUiState()
    data class PhotoUpdated(val newUrl: String) : AuthUiState()
}
