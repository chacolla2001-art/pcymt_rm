package com.univalle.pedrochacolla.utils.session

import android.content.Context

object CredentialsStorage {
    private const val PREF_NAME = "saved_credentials"
    private const val KEY_ENTRIES = "entries"

    fun saveCredential(context: Context, email: String, password: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getStringSet(KEY_ENTRIES, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        existing.add("$email:$password")
        prefs.edit().putStringSet(KEY_ENTRIES, existing).apply()
    }

    fun getSavedCredentials(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_ENTRIES, emptySet()) ?: emptySet()
    }
}
