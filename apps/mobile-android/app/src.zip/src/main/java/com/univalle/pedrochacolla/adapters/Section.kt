package com.univalle.pedrochacolla.adapters

data class Section(
    val title: String,
    val anchors: List<AnchorIcon>
)
