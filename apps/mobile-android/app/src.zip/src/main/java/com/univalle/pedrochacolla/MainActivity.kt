package com.univalle.pedrochacolla

import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.univalle.pedrochacolla.databinding.ActivityMainBinding
import com.univalle.pedrochacolla.utils.ar.InteractionTracker

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        InteractionTracker.init(this)
        val navView: BottomNavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_collection,
                R.id.navigation_main,
                R.id.navigation_home,
                R.id.navigation_dashboard,
                R.id.navigation_notifications
            )
        )

        navView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_collection -> {
                    mostrarBottomNavBar()  // o el comportamiento que prefieras
                    navController.navigate(R.id.navigation_collection)
                    true
                }
                R.id.navigation_main -> {
                    mostrarBottomNavBar()            // o lo que quieras para este tab
                    navController.navigate(R.id.navigation_main)
                    true
                }
                R.id.navigation_home -> {
                    ocultarBottomNavBar()
                    navController.navigate(R.id.navigation_home)
                    true
                }
                R.id.navigation_dashboard -> {
                    mostrarBottomNavBar()
                    navController.navigate(R.id.navigation_dashboard)
                    true
                }
                R.id.navigation_notifications -> {
                    mostrarBottomNavBar()
                    navController.navigate(R.id.navigation_notifications)
                    true
                }
                else -> false
            }
        }
    }



    private fun enterImmersiveMode() {
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.apply {
            hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun reenterImmersiveMode(delayMillis: Long = 3000L) {
        window.decorView.postDelayed({
            window.insetsController?.hide(
                WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
            )
        }, delayMillis)
    }

    fun ocultarBottomNavBar() {
        binding.navView.animate()
            .translationY(binding.navView.height.toFloat())
            .setDuration(300)
            .start()
    }

    fun mostrarBottomNavBar() {
        binding.navView.animate()
            .translationY(0f)
            .setDuration(300)
            .start()
    }

}
