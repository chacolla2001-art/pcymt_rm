package com.univalle.pedrochacolla.ui.notifications

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.univalle.pedrochacolla.R
import com.univalle.pedrochacolla.databinding.FragmentNotificationsBinding
import com.univalle.pedrochacolla.ui.login.AuthUiState
import com.univalle.pedrochacolla.ui.login.LoginActivity
import com.univalle.pedrochacolla.ui.login.LoginViewModel
import com.univalle.pedrochacolla.ui.login.LoginViewModelFactory
import com.univalle.pedrochacolla.utils.constants.Constants
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import com.univalle.pedrochacolla.utils.session.SessionManager
import com.univalle.pedrochacolla.utils.session.UserSession
import com.univalle.pedrochacolla.utils.window.BannerUtil
import kotlinx.coroutines.launch
import java.io.File

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: LoginViewModel by viewModels {
        LoginViewModelFactory(requireContext())
    }

    private lateinit var sessionManager: SessionManager
    private lateinit var pickPhotoLauncher: ActivityResultLauncher<Intent>
    private var originalData: Map<String, String> = emptyMap()
    private var loadingDialog: LoadingDialogFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pickPhotoLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.data?.let { uri ->
                    val file = uriToFile(uri, requireContext())

                    // Validación de tamaño máximo (2 MB)
                    val maxFileSizeBytes = 2 * 1024 * 1024
                    if (file.length() > maxFileSizeBytes) {
                        BannerUtil.showBanner(requireActivity(), "La imagen es demasiado grande. Máximo 2 MB")
                        return@let
                    }

                    Glide.with(this).load(uri).into(binding.etProfileimage)
                    val userId = UserSession.currentUser?.userId.orEmpty()

                    loadingDialog = LoadingDialogFragment.newInstance()
                    loadingDialog?.show(parentFragmentManager, "loading")

                    viewModel.updatePhoto(userId, file)
                }
            }
        }


        Log.d("loginresponse","Hola" )
        Log.d("loginresponse", UserSession.currentUser?.idToken.toString() )

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        sessionManager = SessionManager(requireContext())
        sessionManager.loadSession()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        populateUserData()
        disableForm()

        binding.btnProfileUpdateinfo.setOnClickListener { enableForm() }
        binding.btnProfileCanceleditinfo.setOnClickListener {
            restoreOriginalData()
            disableForm()
            BannerUtil.showBanner(requireActivity(), "Cambios cancelados")
        }

        binding.btnProfileUpdatephoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickPhotoLauncher.launch(intent)
        }

        binding.btnProfileSaveinfo.setOnClickListener { saveChanges() }

        binding.btnLogout.setOnClickListener {
            sessionManager.clearSession()
            val intent = Intent(requireContext(), LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
        }

        observeViewModel()
    }
    override fun onResume() {
        super.onResume()

    }

    private fun saveChanges() {
        val userId = UserSession.currentUser?.userId.orEmpty()
        if (userId.isBlank()) {
            BannerUtil.showBanner(requireActivity(), "ID no disponible")
            return
        }

        val email = binding.etProfileEmail.text.toString().trim()
        val username = binding.etProfileUsername.text.toString().trim()
        val idCard = binding.etProfileIdcardnumber.text.toString().trim()
        val pwd = binding.editTextText.text.toString()
        val pwdRepeat = binding.editTextText2.text.toString()

        if (email.isEmpty() || username.isEmpty() || idCard.isEmpty()) {
            BannerUtil.showBanner(requireActivity(), "Correo, username y CI no pueden estar vacíos")
            return
        }

        if (pwd.isNotEmpty() && pwd != pwdRepeat) {
            BannerUtil.showBanner(requireActivity(), "Las contraseñas no coinciden")
            return
        }

        if (pwd.isNotEmpty() && !esPasswordSegura(pwd)) {
            BannerUtil.showBanner(requireActivity(), "Contraseña insegura: mínimo 12 caracteres, mayúsculas, minúsculas, números y símbolos")
            return
        }

        val updatedFields = mutableMapOf<String, Any>(
            "username" to username,
            "email" to email,
            "full_name" to binding.etProfileFullname.text.toString(),
            "first_lastname" to binding.etProfileFirstlastname.text.toString(),
            "second_lastname" to binding.etProfileSecondlastname.text.toString(),
            "id_card_number" to idCard
        )
        if (pwd.isNotEmpty()) updatedFields["password_hash"] = pwd

        val originalEmail = originalData["email"]
        val originalUsername = originalData["username"]
        val originalIdCard = originalData["id_card_number"]

        lifecycleScope.launch {
            loadingDialog = LoadingDialogFragment.newInstance()
            loadingDialog?.show(parentFragmentManager, "loading")

            if (email != originalEmail && viewModel.checkEmailExists(email)) {
                loadingDialog?.dismiss()
                BannerUtil.showBanner(requireActivity(), "El correo ya existe")
                return@launch
            }
            if (username != originalUsername && viewModel.checkUsernameExists(username)) {
                loadingDialog?.dismiss()
                BannerUtil.showBanner(requireActivity(), "El nombre de usuario ya existe")
                return@launch
            }
            if (idCard != originalIdCard && viewModel.checkIdCardExists(idCard)) {
                loadingDialog?.dismiss()
                BannerUtil.showBanner(requireActivity(), "El número de CI ya está registrado")
                return@launch
            }

            viewModel.updateUserProfile(userId, updatedFields)
        }
    }

    private fun esPasswordSegura(password: String): Boolean {
        val longitudValida = password.length >= 12
        val contieneMayuscula = password.any { it.isUpperCase() }
        val contieneMinuscula = password.any { it.isLowerCase() }
        val contieneNumero = password.any { it.isDigit() }
        val contieneSimbolo = password.any { !it.isLetterOrDigit() }
        return longitudValida && contieneMayuscula && contieneMinuscula && contieneNumero && contieneSimbolo
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                when (state) {
                    is AuthUiState.Loading -> {
                        if (loadingDialog == null) {
                            loadingDialog = LoadingDialogFragment.newInstance()
                            loadingDialog?.show(parentFragmentManager, "loading")
                        }
                    }
                    is AuthUiState.PhotoUpdated -> {
                        loadingDialog?.dismiss()
                        BannerUtil.showBanner(requireActivity(), "Foto actualizada correctamente")
                    }
                    is AuthUiState.UpdateSuccess -> {
                        loadingDialog?.dismiss()
                        BannerUtil.showBanner(requireActivity(), "Datos actualizados correctamente")
                        saveOriginalData()
                        disableForm()
                    }
                    is AuthUiState.Error -> {
                        loadingDialog?.dismiss()
                        BannerUtil.showBanner(requireActivity(), "Error: ${state.message}")
                    }
                    else -> Unit
                }
            }
        }
    }

    private fun populateUserData() {
        val user = UserSession.currentUser ?: return

        val rawUrl = user.profilePictureUrl.orEmpty()
        val imageUrl = if (rawUrl.contains("googleusercontent.com")) rawUrl else Constants.URL_BASE + rawUrl

        Glide.with(requireContext())
            .load(imageUrl)
            .placeholder(R.drawable.ic_profile_placeholder)
            .error(R.drawable.ic_profile_placeholder)
            .into(binding.etProfileimage)

        fun String?.isValid(): Boolean = this != null && this.isNotBlank() && this != "null"

        if (user.username.isValid()) binding.etProfileUsername.setText(user.username)
        if (user.email.isValid()) binding.etProfileEmail.setText(user.email)
        if (user.fullName.isValid()) binding.etProfileFullname.setText(user.fullName)
        if (user.firstLastname.isValid()) binding.etProfileFirstlastname.setText(user.firstLastname)
        if (user.secondLastname.isValid()) binding.etProfileSecondlastname.setText(user.secondLastname)
        if (user.idCardNumber.isValid()) binding.etProfileIdcardnumber.setText(user.idCardNumber)

        saveOriginalData()
    }

    private fun saveOriginalData() {
        originalData = mapOf(
            "username" to binding.etProfileUsername.text.toString(),
            "email" to binding.etProfileEmail.text.toString(),
            "full_name" to binding.etProfileFullname.text.toString(),
            "first_lastname" to binding.etProfileFirstlastname.text.toString(),
            "second_lastname" to binding.etProfileSecondlastname.text.toString(),
            "id_card_number" to binding.etProfileIdcardnumber.text.toString()
        )
    }

    private fun restoreOriginalData() {
        binding.etProfileUsername.setText(originalData["username"])
        binding.etProfileEmail.setText(originalData["email"])
        binding.etProfileFullname.setText(originalData["full_name"])
        binding.etProfileFirstlastname.setText(originalData["first_lastname"])
        binding.etProfileSecondlastname.setText(originalData["second_lastname"])
        binding.etProfileIdcardnumber.setText(originalData["id_card_number"])
    }

    private fun enableForm() = binding.run {
        etProfileUsername.isEnabled = true
        etProfileEmail.isEnabled = true
        etProfileFullname.isEnabled = true
        etProfileFirstlastname.isEnabled = true
        etProfileSecondlastname.isEnabled = true
        etProfileIdcardnumber.isEnabled = true
        tilPassword.isEnabled = true
        editTextText.isEnabled = true
        editTextText2.isEnabled = true
    }

    private fun disableForm() = binding.run {
        etProfileUsername.isEnabled = false
        etProfileEmail.isEnabled = false
        etProfileFullname.isEnabled = false
        etProfileFirstlastname.isEnabled = false
        etProfileSecondlastname.isEnabled = false
        etProfileIdcardnumber.isEnabled = false
        editTextText.isEnabled = false
        editTextText2.isEnabled = false
    }

    private fun uriToFile(uri: Uri, ctx: Context): File {
        val input = ctx.contentResolver.openInputStream(uri)!!
        val outFile = File(ctx.cacheDir, "upload_${System.currentTimeMillis()}.jpg")
        input.use { inp -> outFile.outputStream().use { out -> inp.copyTo(out) } }
        return outFile
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
