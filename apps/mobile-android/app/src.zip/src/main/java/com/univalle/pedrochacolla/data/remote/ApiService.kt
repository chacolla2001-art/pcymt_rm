package com.univalle.pedrochacolla.data.remote

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.univalle.pedrochacolla.data.model.AnchorPoint
import com.univalle.pedrochacolla.data.model.AnimalModel
import com.univalle.pedrochacolla.data.model.UserInteraction
import com.univalle.pedrochacolla.utils.constants.Constants
import com.univalle.pedrochacolla.utils.session.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

class ApiService {
    private val client = OkHttpClient()

    companion object {
        const val BASE_URL = Constants.URL_BASE
    }

    private val token: String? get() = UserSession.currentUser?.idToken
    suspend fun loginWithGoogle(idToken: String): Result<Pair<String, JSONObject>> = withContext(Dispatchers.IO) {
        try {
            val formBody = FormBody.Builder()
                .add("id_token", idToken)
                .add("platform", "mobile")
                .build()

            val request = Request.Builder()
                .url(BASE_URL + Constants.URL_LOGGING_GOOGLE)
                .post(formBody)
                .build()

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                Result.failure(Exception("HTTP error ${response.code}"))
            } else {
                val body = response.body?.string()

                val json = JSONObject(body ?: "{}")
                if (json.has("token")) {
                    val token = json.getString("token")
                    Result.success(Pair(token, json))
                } else {
                    Result.failure(Exception("Token not found in response"))
                }
            }
        } catch (e: Exception) {
            Log.e("LoginViewModel", "Exception: ${e.message}", e)
            Result.failure(e)
        }
    }
    suspend fun getInteractedAnchors(userId: String, token: String): List<String> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions/user/$userId/anchors")
            .addHeader("Authorization", "Bearer $token")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.w("ApiService", "getInteractedAnchors HTTP ${response.code}")
                return@withContext emptyList()
            }
            val body = response.body?.string().orEmpty()
            // Parsear array de AnchorPoint y extraer sus IDs
            return@withContext Gson()
                .fromJson(body, Array<AnchorPoint>::class.java)
                .mapNotNull { it.id }
        }
    }
    suspend fun getAllAnchorPoints(token: String): List<AnchorPoint>? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/anchorpoints/activos")
            .addHeader("Authorization", "Bearer $token")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null
        val json = response.body?.string() ?: return@withContext null
        Gson().fromJson(json, Array<AnchorPoint>::class.java).toList()
    }

    suspend fun createAnchorPoint(token: String, anchor: AnchorPoint): Boolean = withContext(Dispatchers.IO) {
        val json = Gson().toJson(anchor)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/anchorpoints")
            .post(body)
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun updateAnchorPoint(id: String, token: String, anchor: AnchorPoint): Boolean = withContext(Dispatchers.IO) {
        val json = Gson().toJson(anchor)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/anchorpoints/$id")
            .put(body)
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun deleteAnchorPoint(id: String, token: String): Boolean = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/anchorpoints/$id")
            .delete()
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun getAllAnimalModels(token: String): List<AnimalModel>? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/animalmodels")
            .addHeader("Authorization", "Bearer $token")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null
        val json = response.body?.string() ?: return@withContext null
        Gson().fromJson(json, Array<AnimalModel>::class.java).toList()
    }

    suspend fun getAnimalModelById(id: String, token: String): AnimalModel? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/animalmodels/$id")
            .addHeader("Authorization", "Bearer $token")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null
        val json = response.body?.string() ?: return@withContext null
        Gson().fromJson(json, AnimalModel::class.java)
    }

    suspend fun createAnimalModel(token: String, model: AnimalModel): Boolean = withContext(Dispatchers.IO) {
        val json = Gson().toJson(model)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/animalmodels")
            .post(body)
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun updateAnimalModel(id: String, token: String, model: AnimalModel): Boolean = withContext(Dispatchers.IO) {
        val json = Gson().toJson(model)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/animalmodels/$id")
            .put(body)
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun deleteAnimalModel(id: String, token: String): Boolean = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$BASE_URL/api/animalmodels/$id")
            .delete()
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute().isSuccessful
    }

    suspend fun updateProfilePhoto(userId: String, imageFile: File, token: String): Response = withContext(Dispatchers.IO) {
        val mediaType = "image/*".toMediaTypeOrNull()
        val fileBody = imageFile.asRequestBody(mediaType)
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("profile_picture_url", imageFile.name, fileBody)
            .build()
        val request = Request.Builder()
            .url("$BASE_URL/api/users/$userId")
            .put(multipart)
            .addHeader("Authorization", "Bearer $token")
            .build()
        client.newCall(request).execute()
    }

    suspend fun checkEmailExistence(email: String): Boolean = withContext(Dispatchers.IO) {
        val response = post("/api/users/check-email", mapOf("email" to email))
        if (!response.isSuccessful) return@withContext false
        val json = JSONObject(response.body?.string() ?: "{}")
        json.optBoolean("exists", false)
    }

    suspend fun checkUsernameExistence(username: String): Boolean = withContext(Dispatchers.IO) {
        val response = post("/api/users/check-username", mapOf("username" to username))
        if (!response.isSuccessful) return@withContext false
        val json = JSONObject(response.body?.string() ?: "{}")
        json.optBoolean("exists", false)
    }

    suspend fun checkIdCardExistence(ci: String): Boolean = withContext(Dispatchers.IO) {
        val response = post("/api/users/check-id-card", mapOf("id_card_number" to ci))
        if (!response.isSuccessful) return@withContext false
        val json = JSONObject(response.body?.string() ?: "{}")
        json.optBoolean("exists", false)
    }

    suspend fun post(endpoint: String, params: Map<String, Any>): Response = withContext(Dispatchers.IO) {
        val gson = Gson()
        val jsonBody = gson.toJson(params)
        val requestBody = jsonBody.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(BASE_URL + endpoint)
            .post(requestBody)
            .build()
        client.newCall(request).execute()
    }

    suspend fun put(endpoint: String, params: Map<String, Any>): Response = withContext(Dispatchers.IO) {
        val gson = Gson()
        val jsonBody = gson.toJson(params)
        val requestBody = jsonBody.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(BASE_URL + endpoint)
            .put(requestBody)
            .build()
        client.newCall(request).execute()
    }

    suspend fun getAllUserInteractions(context: Context): List<UserInteraction>? = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context)

        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions")
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null

        val bodyString = response.body?.string() ?: return@withContext null
        val type = object : TypeToken<List<UserInteraction>>() {}.type
        Gson().fromJson<List<UserInteraction>>(bodyString, type)
    }

    suspend fun getUserInteractionById(context: Context, id: String): UserInteraction? = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context)

        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions/$id")
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null

        val bodyString = response.body?.string() ?: return@withContext null
        Gson().fromJson(bodyString, UserInteraction::class.java)
    }

    suspend fun createUserInteraction(context: Context, interaction: UserInteraction): Boolean = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context, false) == true

        val json = Gson().toJson(interaction)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions")
            .post(body)
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        client.newCall(request).execute().isSuccessful
    }

    suspend fun updateUserInteraction(context: Context, id: String, interaction: UserInteraction): Boolean = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context, false) == true

        val json = Gson().toJson(interaction)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions/$id")
            .put(body)
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        client.newCall(request).execute().isSuccessful
    }

    suspend fun deleteUserInteraction(context: Context, id: String): Boolean = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context, false) == true

        val request = Request.Builder()
            .url("$BASE_URL/api/userinteractions/$id")
            .delete()
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        client.newCall(request).execute().isSuccessful
    }

    suspend fun getInteractionsByAnimalModel(context: Context, cerm: String, range: String): List<UserInteraction>? = withContext(Dispatchers.IO) {
        val authToken = token ?: return@withContext mostrarErrorAuth(context)

        val request = Request.Builder()
            .url("$BASE_URL/api/analytics/by-animal-model/$cerm?range=$range")
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext null

        val bodyString = response.body?.string() ?: return@withContext null
        val type = object : TypeToken<List<UserInteraction>>() {}.type
        Gson().fromJson<List<UserInteraction>>(bodyString, type)
    }

    // Función auxiliar para mostrar error y devolver null o false según tipo
    private suspend fun <T> mostrarErrorAuth(context: Context, value: T? = null): T? {
        withContext(Dispatchers.Main) {
            Toast.makeText(context, "Usuario no autenticado", Toast.LENGTH_LONG).show()
        }
        return value
    }


}
