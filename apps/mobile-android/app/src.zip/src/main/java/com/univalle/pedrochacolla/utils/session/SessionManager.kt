package com.univalle.pedrochacolla.utils.session

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.univalle.pedrochacolla.data.model.UserData

class SessionManager(context: Context) {
    private val authPrefs: SharedPreferences = context.getSharedPreferences("auth_session", Context.MODE_PRIVATE)
    private val configPrefs: SharedPreferences = context.getSharedPreferences("user_config", Context.MODE_PRIVATE)

    fun saveSession(user: UserData) {
        authPrefs.edit().apply {
            putString("idToken", user.idToken)
            putString("userId", user.userId)
            putString("userEmail", user.email)
            putString("username", user.username)
            putString("userRole", user.userRole)
            putString("fullName", user.fullName)
            putString("firstLastname", user.firstLastname)
            putString("secondLastname", user.secondLastname)
            putString("idCardNumber", user.idCardNumber)
            putString("profilePictureUrl", user.profilePictureUrl)
            putString("createdAt", user.createdAt)
            putString("updatedAt", user.updatedAt)
            apply()
        }
        UserSession.currentUser = user
    }

    fun loadSession(): Boolean {
        val token = authPrefs.getString("idToken", null) ?: return false
        UserSession.currentUser = UserData(
            idToken = token,
            userId = authPrefs.getString("userId", "") ?: "",
            username = authPrefs.getString("username", "") ?: "",
            email = authPrefs.getString("userEmail", "") ?: "",
            password = null,
            userRole = authPrefs.getString("userRole", "user") ?: "user",
            active = true,
            fullName = authPrefs.getString("fullName", null),
            firstLastname = authPrefs.getString("firstLastname", null),
            secondLastname = authPrefs.getString("secondLastname", null),
            idCardNumber = authPrefs.getString("idCardNumber", null),
            profilePictureUrl = authPrefs.getString("profilePictureUrl", null),
            createdAt = authPrefs.getString("createdAt", null),
            updatedAt = authPrefs.getString("updatedAt", null)
        )
        Log.d("pedro2",UserSession.currentUser.toString())
        return true
    }

    fun clearSession() {
        authPrefs.edit().clear().apply()
        UserSession.clear()
    }

    fun setRememberMe(enabled: Boolean, method: String? = null, email: String? = null, password: String? = null) {
        configPrefs.edit().apply {
            putBoolean("remember_me", enabled)
            if (enabled) {
                method?.let { putString("login_method", it) }
                email?.let { putString("remembered_email", it) }
                password?.let { putString("remembered_password", it) }
            } else {
                remove("login_method")
                remove("remembered_email")
                remove("remembered_password")
            }
            apply()
        }
    }

    fun saveCredentials(email: String, password: String) {
        configPrefs.edit()
            .putString("remembered_email", email)
            .putString("remembered_password", password)
            .apply()
    }

    fun getSavedCredentials(): Pair<String?, String?> {
        val email = configPrefs.getString("remembered_email", null)
        val password = configPrefs.getString("remembered_password", null)
        return Pair(email, password)
    }

    fun isRememberMeEnabled(): Boolean = configPrefs.getBoolean("remember_me", false)
    fun getLoginMethod(): String? = configPrefs.getString("login_method", null)
    fun getRememberedEmail() = configPrefs.getString("remembered_email", "")
    fun getRememberedPassword() = configPrefs.getString("remembered_password", "")
}
