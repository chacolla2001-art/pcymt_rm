package com.univalle.pedrochacolla.utils.window


import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.Guideline
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

object WindowInsetsUtil {
    /**
     * Ajusta dos Guidelines (top y bottom) según los system gesture insets
     * y la altura de la ActionBar.
     */
    fun applyInsetsToGuidelines(
        rootView: View,
        topGuideline: Guideline,
        bottomGuideline: Guideline,
        activity: AppCompatActivity
    ) {
        ViewCompat.setOnApplyWindowInsetsListener(topGuideline) { _, insets ->
            val actionBarHeight = activity.supportActionBar?.height ?: 0
            topGuideline.setGuidelineBegin(insets.systemGestureInsets.top + actionBarHeight)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomGuideline) { _, insets ->
            bottomGuideline.setGuidelineEnd(insets.systemGestureInsets.bottom)
            WindowInsetsCompat.CONSUMED
        }
        // Fuerza la aplicación inmediata
        ViewCompat.requestApplyInsets(rootView)
    }
}