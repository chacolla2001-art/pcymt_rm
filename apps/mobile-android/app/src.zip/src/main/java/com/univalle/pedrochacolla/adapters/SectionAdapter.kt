package com.univalle.pedrochacolla.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.univalle.pedrochacolla.R

/**
 * Data class de cada sección: un título y una lista de AnchorIcon.
 */

/**
 * Adapter vertical para mostrar secciones.
 *
 * @param sections Lista de secciones a mostrar.
 * @param interactedIds Set de anchorId con los que el usuario ya ha interactuado.
 * @param onIconClick Callback cuando el usuario pulsa un icono.
 */
class SectionAdapter(
    private val sections: List<Section>,
    private val interactedIds: Set<String>,
    private val onIconClick: (AnchorIcon) -> Unit
) : RecyclerView.Adapter<SectionAdapter.SectionViewHolder>() {

    inner class SectionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSectionTitle: TextView = itemView.findViewById(R.id.tvSectionTitle)
        val rvIcons: RecyclerView   = itemView.findViewById(R.id.rvIcons)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SectionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_section, parent, false)
        return SectionViewHolder(view)
    }

    override fun getItemCount(): Int = sections.size

    override fun onBindViewHolder(holder: SectionViewHolder, position: Int) {
        val section = sections[position]
        // Fija el título
        holder.tvSectionTitle.text = section.title

        // Configura el RecyclerView horizontal interno
        holder.rvIcons.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = IconAdapter(
                items = section.anchors,
                interactedIds = interactedIds,
                onClick = onIconClick
            )
        }
    }
}
