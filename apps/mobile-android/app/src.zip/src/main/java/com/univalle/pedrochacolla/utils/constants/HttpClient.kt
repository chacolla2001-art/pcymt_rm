package com.univalle.pedrochacolla.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

object HttpClient {
    private val client = OkHttpClient()

    fun pingServer(serverUrl: String, onResult: (Boolean) -> Unit) {
        val request = Request.Builder()
            .url("$serverUrl/api/ping")
            .build()

        Thread {
            try {
                val response = client.newCall(request).execute()
                onResult(response.isSuccessful)
            } catch (e: IOException) {
                onResult(false)
            }
        }.start()
    }
}