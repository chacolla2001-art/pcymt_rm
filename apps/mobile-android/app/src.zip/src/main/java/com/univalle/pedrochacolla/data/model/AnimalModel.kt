package com.univalle.pedrochacolla.data.model

import java.util.Date

data class AnimalModel(
    val id: String? = null,
    val name: String,
    val species: String,
    val description: String? = null,
    val modelURL: String,
    val icon: String? = null,
    val animation_sequence: List<AnimationClip>?,
    val active: Boolean = true,
    val createdAt: Date? = null,
    val updatedAt: Date? = null
)
