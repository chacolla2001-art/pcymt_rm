package com.univalle.pedrochacolla.ui.login

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.univalle.pedrochacolla.data.model.UserData
import com.univalle.pedrochacolla.data.repository.AuthRepository
import com.univalle.pedrochacolla.utils.session.SessionManager
import com.univalle.pedrochacolla.utils.session.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class LoginViewModel(
    private val repository: AuthRepository,
    private val context: Context
) : ViewModel() {

    private val _state = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val state: StateFlow<AuthUiState> = _state

    private val session = SessionManager(context)

    fun loginWithGoogle(idToken: String, remember: Boolean) {
        viewModelScope.launch {
            _state.value = AuthUiState.Loading
            repository.loginWithGoogleIdToken(idToken).onSuccess { (token, json) ->
                Log.d("pedro1", json.toString())

                // 1) Obtenemos el sub‐objeto "user"
                val userJson = json.optJSONObject("user")
                    ?: run {
                        _state.value = AuthUiState.Error("Respuesta inesperada del servidor")
                        return@onSuccess
                    }

                // 2) Extraemos campos del usuario (incluyendo profile_picture_url y locale)
                val user = UserData(
                    idToken           = token,
                    userId            = userJson.optString("user_id", ""),
                    username          = userJson.optString("username", ""),
                    email             = userJson.optString("email", ""),
                    password          = null,
                    userRole          = userJson.optString("user_role", "user"),
                    active            = userJson.optBoolean("active", true),
                    fullName          = userJson.optString("full_name", null),
                    firstLastname     = userJson.optString("first_lastname", null),
                    secondLastname    = userJson.optString("second_lastname", null),
                    idCardNumber      = userJson.optString("id_card_number", null),
                    profilePictureUrl = userJson.optString("profile_picture_url", null),
                    // si quieres guardar locale en UserData, añade un campo
                    createdAt         = userJson.optString("created_at", null),
                    updatedAt         = userJson.optString("updated_at", null)
                )

                // 3) Guardamos sesión y preferencias
                session.saveSession(user)
                session.setRememberMe(remember, "google")

                _state.value = AuthUiState.LoginSuccess
            }.onFailure {
                _state.value = AuthUiState.Error(it.message ?: "Error con Google")
            }
        }
    }


    fun loginWithEmailAndPassword(email: String, password: String, remember: Boolean) {
        viewModelScope.launch {
            _state.value = AuthUiState.Loading
            repository.loginWithEmail(email, password).onSuccess { (token, json) ->
                Log.d("pedro1", json.toString())

                // 1) Obtenemos el objeto "user" del JSON
                val userJson = json.optJSONObject("user")
                    ?: run {
                        _state.value = AuthUiState.Error("Respuesta inesperada del servidor")
                        return@onSuccess
                    }

                // 2) Extraemos campos del sub‐objeto
                val user = extractUser(token, userJson)

                // 3) Guardamos sesión
                session.saveSession(user)
                session.setRememberMe(remember, "email", email, password)

                _state.value = AuthUiState.LoginSuccess
            }.onFailure {
                _state.value = AuthUiState.Error(it.message ?: "Error con Email")
            }
        }
    }


    fun registerUser(user: UserData) {
        viewModelScope.launch {
            _state.value = AuthUiState.Loading
            val request = user.toRegisterMap()

            try {
                val (token, userJson) = withContext(Dispatchers.IO) {
                    val response = repository.registerUser(request)
                    val body = response.body?.string() ?: "{}"
                    val json = JSONObject(body)
                    val token = json.optString("token", null)
                    val userJson = json.optJSONObject("user")
                    if (token == null || userJson == null) throw Exception("Respuesta inválida")
                    Pair(token, userJson)
                }

                val newUser = extractUser(token, userJson)
                session.saveSession(newUser)
                _state.value = AuthUiState.LoginSuccess

            } catch (e: Exception) {
                _state.value = AuthUiState.Error("Excepción: ${e.message}")
            }
        }
    }



    private fun extractUser(token: String, json: JSONObject) = UserData(
        idToken = token,
        userId = json.optString("user_id", ""),
        email = json.optString("email", ""),
        username = json.optString("username", ""),
        userRole = json.optString("user_role", "user"),
        fullName = json.optString("full_name", null),
        firstLastname = json.optString("first_lastname", null),
        secondLastname = json.optString("second_lastname", null),
        idCardNumber = json.optString("id_card_number", null),
        profilePictureUrl=json.optString("profile_picture_url", null)
    )
    /**
     * Lanza la petición para actualizar los datos del usuario y emite
     * UpdateSuccess o Error en el StateFlow.
     */
    fun updateUserProfile(userId: String, updatedData: Map<String, Any>) {
        viewModelScope.launch {
            _state.value = AuthUiState.Loading
            repository.updateUser(userId, updatedData)
                .onSuccess {
                    val current = UserSession.currentUser ?: return@onSuccess

                    val updatedUser = current.copy(
                        username       = updatedData["username"]        as? String ?: current.username,
                        email          = updatedData["email"]           as? String ?: current.email,
                        fullName       = updatedData["full_name"]       as? String ?: current.fullName,
                        firstLastname  = updatedData["first_lastname"]  as? String ?: current.firstLastname,
                        secondLastname = updatedData["second_lastname"] as? String ?: current.secondLastname,
                        idCardNumber   = updatedData["id_card_number"]  as? String ?: current.idCardNumber,
                        password       = updatedData["password"]        as? String ?: current.password,
                        updatedAt      = current.updatedAt
                    )

                    // Persistir en memoria y en SharedPreferences
                    UserSession.currentUser = updatedUser
                    session.saveSession(updatedUser)

                    _state.value = AuthUiState.UpdateSuccess
                }
                .onFailure {
                    _state.value = AuthUiState.Error(it.message ?: "Error al actualizar perfil")
                }
        }
    }


    fun updatePhoto(userId: String, imageFile: File) {
        val token = UserSession.currentUser?.idToken.orEmpty()
        viewModelScope.launch {
            _state.value = AuthUiState.Loading
            repository.uploadProfilePhoto(userId, imageFile, token)
                .onSuccess { newUrl ->
                    // 1) Actualizamos el modelo en memoria
                    val updatedUser = UserSession.currentUser?.copy(
                        profilePictureUrl = newUrl,
                        updatedAt = /* opcional: fecha actual o la que venga del servidor */
                        UserSession.currentUser!!.updatedAt
                    ) ?: return@onSuccess

                    UserSession.currentUser = updatedUser

                    // 2) Persistimos TODO el objeto UserData en SharedPrefs
                    session.saveSession(updatedUser)

                    // 3) Emitimos estado de éxito de foto
                    _state.value = AuthUiState.PhotoUpdated(newUrl)
                }
                .onFailure {
                    _state.value = AuthUiState.Error(it.message ?: "Error subiendo foto")
                }
        }
    }
    // VERIFICACIONES EXTERNAS
    suspend fun checkEmailExists(email: String): Boolean {
        return repository.emailExists(email)
    }

    suspend fun checkUsernameExists(username: String): Boolean {
        return repository.usernameExists(username)
    }

    suspend fun checkIdCardExists(ci: String): Boolean {
        return repository.idCardExists(ci)
    }
}
