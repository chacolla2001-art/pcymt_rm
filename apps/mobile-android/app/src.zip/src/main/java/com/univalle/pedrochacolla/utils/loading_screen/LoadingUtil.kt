package com.univalle.pedrochacolla.utils.loading_screen

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import com.univalle.pedrochacolla.R

object LoadingUtil {
    fun show(context: Context): AlertDialog {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null)

        val dialog = AlertDialog.Builder(context, R.style.TransparentDialog)
            .setView(view)
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            // Forzar que el dialogo ocupe toda la pantalla
            dialog.window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        }

        dialog.show()
        return dialog
    }
}
