package com.univalle.pedrochacolla

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.model.LatLng
import com.univalle.pedrochacolla.adapters.AnchorIcon
import com.univalle.pedrochacolla.adapters.Section
import com.univalle.pedrochacolla.adapters.SectionAdapter
import com.univalle.pedrochacolla.data.model.AnchorPoint
import com.univalle.pedrochacolla.data.remote.ApiService
import com.univalle.pedrochacolla.utils.loading_screen.LoadingDialogFragment
import com.univalle.pedrochacolla.utils.session.UserSession
import kotlinx.coroutines.launch

class MainFragment : Fragment(R.layout.fragment_main) {

    private val sectionLabels = mapOf(
        "1" to "Altiplano",
        "2" to "Valles",
        "3" to "Llanos"
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rvSections = view.findViewById<RecyclerView>(R.id.rvSections).apply {
            layoutManager = LinearLayoutManager(requireContext())
        }

        // 1) Mostrar diálogo de carga
        val loading = LoadingDialogFragment.newInstance().also {
            it.show(childFragmentManager, "loading")
        }

        lifecycleScope.launch {
            try {
                // 2) Validar sesión
                val user   = UserSession.currentUser
                val token  = user?.idToken
                val userId = user?.userId
                if (token.isNullOrEmpty() || userId.isNullOrEmpty()) {
                    Toast.makeText(requireContext(), "Sesión inválida", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val api = ApiService()

                // 3) Obtener IDs de anchors ya interactuados
                val interactedSet = api.getInteractedAnchors(userId, token).toSet()

                // 4) Cargar y filtrar todos los AnchorPoints
                val allAnchors = api.getAllAnchorPoints(token) ?: emptyList()
                val filteredAnchors = allAnchors.filter {
                    it.active && it.showInMap == true
                            && it.animalModelId != null
                            && it.section != null
                }

                // 5) Agrupar por sección
                val groupedBySection: Map<String, List<AnchorPoint>> =
                    filteredAnchors.groupBy { it.section!!.toString() }

                // 6) Construir lista de Section
                val sections: List<Section> = groupedBySection.map { (code, list) ->
                    Section(
                        title = sectionLabels[code] ?: "Sin sección",
                        anchors = list.mapNotNull { anchor ->
                            api.getAnimalModelById(anchor.animalModelId!!, token)?.let { model ->
                                model.icon?.let { iconPath ->
                                    AnchorIcon(
                                        anchorId    = anchor.id ?: "",
                                        iconUrl     = iconPath,
                                        position    = LatLng(anchor.latitude, anchor.longitude),
                                        description = model.name
                                    )
                                }
                            }
                        }
                    )
                }

                // 7) Asignar adapter con interactedSet
                rvSections.adapter = SectionAdapter(
                    sections = sections,
                    interactedIds = interactedSet
                ) { icon ->
                    findNavController().navigate(
                        R.id.navigation_dashboard,
                        bundleOf("selectedAnchorId" to icon.anchorId)
                    )
                }

                if (sections.isEmpty()) {
                    Toast.makeText(requireContext(), "No hay puntos activos para mostrar.", Toast.LENGTH_SHORT).show()
                }
            } finally {
                // 8) Cerrar diálogo de carga
                loading.dismiss()
            }
        }
    }
}
