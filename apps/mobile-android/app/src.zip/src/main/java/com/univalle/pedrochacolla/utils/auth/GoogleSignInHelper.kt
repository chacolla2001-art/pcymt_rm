package com.univalle.pedrochacolla.utils.auth
import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.credentials.*
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.univalle.pedrochacolla.utils.constants.Constants
import java.util.concurrent.Executors

class GoogleSignInHelper(
    private val context: Context,
    private val activity: Activity,
    private val onTokenReceived: (String) -> Unit,
    private val onError: (String) -> Unit
) {

    fun launch() {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(Constants.WEB_CLIENT_ID)
            .setAutoSelectEnabled(false)
            .setNonce("nonce-string")
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val credentialManager = CredentialManager.create(context)
        val executor = Executors.newSingleThreadExecutor()

        credentialManager.getCredentialAsync(
            activity,
            request,
            null,
            executor,
            object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                override fun onResult(result: GetCredentialResponse) {
                    val credential = result.credential
                    if (credential is GoogleIdTokenCredential) {
                        onTokenReceived(credential.idToken)
                    } else {
                        onError("Credencial inválida")
                    }
                }

                override fun onError(e: GetCredentialException) {
                    onError(e.message ?: "Error desconocido")
                }
            }
        )
    }
}
